import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../services/api-service.service';
import { SessionService } from '../../../services/session.service';
import { ToastrService } from 'ngx-toastr';
import { strictEmailValidator } from '../../custom-validator/strict-email.validator';
import { LoaderComponent } from '../common/loader/loader.component';

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule,LoaderComponent],
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  profileForm!: FormGroup;
  profilePhoto: string | ArrayBuffer | null = null;
  userId: string = "";

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private sessionService: SessionService,
    private toastr: ToastrService
  ) {}
  isLoading :boolean=false;
  ngOnInit(): void {
    
    this.userId = this.sessionService.getSessionData("memberId") || "";

    // Initialize the form with default values and validators
    this.profileForm = this.fb.group({
      name: ['', [Validators.required]],
      email: [{ value: '', disabled: true }],
      //email: ['', [Validators.required, strictEmailValidator()]],
      phone: [ '', [ Validators.required , Validators.pattern(/^\+?[1-9]\d{1,14}$/) ]],
      company: [''],
      title: [''],
      address: ['']
    });

    // Load user data into the form
    this.loadUserData();
  }

  loadUserData(): void {
    
     let sessionData = this.sessionService.getSessionData("data")
    const mockUserData = {
      name: sessionData.name || "",
      email: sessionData.email || "",
      phone: sessionData.phoneNumber || "",
      company: sessionData.company || "",
      title: sessionData.title || "",
      address: sessionData.address || " ",
      profilePhoto: sessionData.profile || null 
    };

    // Populate the form with user data
    this.profileForm.patchValue(mockUserData);
    this.profilePhoto = mockUserData.profilePhoto;
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];

    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.profilePhoto = e.target?.result || null; // Ensure fallback to null
      };
      reader.readAsDataURL(file);
    } else {
      this.profilePhoto = null; // Handle no file selected
    }
  }

  onSubmit(): void {
    if (this.profileForm.valid) {
      this.isLoading=true;
     
      const pData = {
        userId: this.userId,
        name: this.profileForm.value.name,
       // emailId: this.profileForm.value.email,
        phoneNumber: this.profileForm.value.phone,
        company: this.profileForm.value.company,
        title: this.profileForm.value.title,
        address: this.profileForm.value.address
      };

      const updatedProfile = { ...pData, profilePhoto: this.profilePhoto };

      console.log('Updated Profile:', updatedProfile);
  
      this.authService.updateProfile(updatedProfile).subscribe({
        next: (response) => {
          if(!response.error){
           
            this.isLoading=false;

            this.toastr.success(response.message, '');            
           
          }else{
            this.isLoading=false;

            this.toastr.error(response.message, 'Error');
          }
         // this.toastr.success('Profile updated successfully!');
          console.log('Server Response:', response);
        },
        error: (err) => {
          this.isLoading=false;
          this.toastr.error('Failed to update profile. Please try again.');
          console.error('Error:', err);
        }
      });
    } else {
      
      this.toastr.warning('Please fill out the required fields correctly.');
    }
  }
}
